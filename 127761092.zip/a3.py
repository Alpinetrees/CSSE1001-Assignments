import tkinter as tk

from typing import Union, Callable
from tkinter import messagebox, simpledialog
from PIL import Image, ImageTk

from a2_solution import*
from a3_support import AbstractGrid
from constants import GAME_FILE, TASK

# Write your classes here


#Global variables:
player_motion = [UP, DOWN, LEFT, RIGHT]
coin = "Coin"
inventory_dimension = (2, 4)
tile_images = {}
entities_images = {}
    
class LevelView(AbstractGrid):
    """
    A view class that inherits from AbstractGrid.
    Displays the maze (tiles) along with the entities.
    Supports the creation of Levelview.
    """
    def __init__(self,
                 master: Union[tk.Tk, tk.Frame],
                 dimensions: tuple[int, int],
                 size: tuple[int, int],
                 **kwargs) -> None:
        """
        Instantiates LevelView.

        Parameters:
            master: The master frame for ths LevelView.
            dimensions: the number of rows and columns of level
            size: the width and height in pixels
        """
        self._size = size
        self._dimensions = dimensions
        super().__init__(master,
                         dimensions,
                         size,
                         **kwargs)
        
    def draw(self,
             tiles: list[list[Tile]],
             items: dict[tuple[int, int], Item],
             player_pos: tuple[int, int])-> None:
        """
        Clears and redraws the entire level (maze and entities)

        Parameters:
            tiles: the list containing information for tiles.
            items: the dictionary containing information for item entities.
            player_ps: the tuple containing information for the position of the player.
        """
        num_rows, num_columns = self._dimensions
        for row in range(num_rows):
            for column in range(num_columns):
                #draw tiles
                self._tile = tiles[row][column]
                self.create_rectangle(self.get_bbox((row, column)),
                                      fill=TILE_COLOURS[self._tile.get_id()])
                #draw item
                if (row, column) in items:
                    self.create_oval(self.get_bbox((row, column)),
                                     fill=ENTITY_COLOURS[items.get((row, column)).get_id()])
                    self.annotate_position((row, column),
                                           text=items.get((row, column)).get_id())
                #draw player
                elif (row, column) == player_pos:
                    self.create_oval(self.get_bbox((row, column)),
                                     fill=ENTITY_COLOURS[PLAYER])
                    self.annotate_position((row, column),
                                           text=PLAYER)
        

class ImageLevelView(LevelView):
    """
    Extends existing LevelView insatance. Uses images to display tiles and entities.
    ImageLevelView displayed when TASK in constant.py set to 2.
    """
    def __init__(self,
                 master: Union[tk.Tk, tk.Frame],
                 dimensions: tuple[int, int],
                 size: tuple[int, int],
                 **kwargs) -> None:
        """
        Instantiates ImageLevelView.

        Parameters:
            master: The master frame for ths LevelView.
            dimensions: the number of rows and columns of level
            size: the width and height in pixels
        """
        super().__init__(master,
                         dimensions,
                         size,
                         **kwargs)

            
    def draw(self,
             tiles: list[list[Tile]],
             items: dict[tuple[int, int], Item],
             player_pos: tuple[int, int]) -> None:
        """
        Clears and redraws the entire level (maze and entities) using the images. 

        Parameters:
            tiles: the list containing information for tiles.
            items: the dictionary containing information for item entities.
            player_ps: the tuple containing information for the position of the player.
        """
        width, height = self.get_cell_size()
        num_rows, num_columns = self._dimensions

        #holds the resized tile images in dictionary.
        for tile in TILE_IMAGES:
            image = Image.open(f'images/{TILE_IMAGES[tile]}').resize((width, height))
            tile_images[tile] = ImageTk.PhotoImage(image)

        #holds the resized entity images in dictionary.
        for entity in ENTITY_IMAGES:
            image = Image.open(f'images/{ENTITY_IMAGES[entity]}').resize((width, height))
            entities_images[entity] = ImageTk.PhotoImage(image)
            
        for row in range(num_rows):
            for column in range(num_columns):
                x_mid, y_mid = self.get_midpoint((row, column))
                #draw tile
                self.create_image(x_mid,
                                  y_mid,
                                  image=tile_images[tiles[row][column].get_id()])
                #draw item
                if (row, column) in items:
                    self.create_image(x_mid,
                                      y_mid,
                                      image=entities_images[items.get((row, column)).get_id()])
                #draw player
                elif (row, column) == player_pos:
                    self.create_image(x_mid,
                                      y_mid,
                                      image=entities_images[PLAYER])
                
class StatsView(AbstractGrid):
    """
    View class inhertis from AbstractGrid,
    Displays the player’s stats (HP, health, thirst),
    along with the number of coins collected.
    Supports creation of StatsView.
    """
    def __init__(self,
                 master: Union[tk.Tk, tk.Frame],
                 width: int,
                 **kwargs) -> None:
        """
        Instantiates StatsView
        Sets up new statsview in master with given width.

        Parameters:
            master: The master frame of the StatsView.
            width: the given width of the inventory.
            **kwargs: dictionary of keyword arguments.
        """
        super().__init__(master,
                         inventory_dimension,
                         (INVENTORY_WIDTH + MAZE_WIDTH, STATS_HEIGHT),
                         bg=THEME_COLOUR)
    
    def draw_stats(self, player_stats: tuple[int, int, int]) -> None:
        """
        Draws the stats of the player.

        Parameters:
            player_stats: the health, hunger and thirst of player in tuple.
        """
        self._row, self._column = (inventory_dimension)
        self._msg = [["HP", "Hunger", "Thirst"],
                     [player_stats[0], player_stats[1], player_stats[2]]]
        
        for row in range(self._row):
            for column in range(self._column-1):
                self.annotate_position((row, column), text = self._msg[row][column])
        
    def draw_coins(self, num_coins: int) -> None:
        """
        Draws the number of coins.
        
        Parameters:
            num_coins: the number of coins in player inventory. 
        """
        self.annotate_position((0, 3), text = "Coins")
        self.annotate_position((1, 3), text = num_coins)


class InventoryView(tk.Frame):
    """
    View class inherits from tk.Frame and displays the items the player has in inventory,
    via tk.Labels, under title Label.
    """
    def __init__(self, master: Union[tk.Tk, tk.Frame], **kwargs) -> None:
        """
        Instantiates a new InventoryView.

        Parameters:
            master: the master frame.
            **kwargs: dictionary of keyword arguments.
        """
        super().__init__(master, width=INVENTORY_WIDTH, bg = THEME_COLOUR, **kwargs)
        
        self._labels = []
        self._lbl = None

    def set_click_callback(self, callback: Callable[[str], None]) -> None:
        """
        Sets the function to be called when an item is clicked.

        Parameters:
            callback: function or method passed to LocalSolver.
        """
        for lbl in self._labels:
            name = self._lbl.cget("text").split(":")[0]
            lbl.bind("<Button-1>", lambda user_useage: callback(name))

    def clear(self) -> None:
        """
        Clears all child widgets from this Inventory View.
        """
        for widgit in self.winfo_children():
            widgit.destroy()

    def _draw_item(self, name: str, num: int, colour: str) -> None:
        """
        Creates and binds a single tk.Label in InventoryView frame.

        Parameters:
            name: the name of the item.
            num: the quantity currently in user inventory.
            colour: the background colour for item label determined by type of item. 
        """
        self._lbl = tk.Label(self, text=f"{name}: {num}", font=TEXT_FONT, bg=colour)
        self._labels.append(self._lbl)
        self._lbl.pack(side=tk.TOP, fill=tk.X)
        

    def draw_inventory(self, inventory: Inventory) -> None:
        """
        Draws non-coin inventory items with quantities and binds the callback for each,
        if a click callback has been set.

        Paramters:
            inventory: the inventory of the player.
        """
        self._lbl = tk.Label(self, text="Inventory", font=HEADING_FONT)
        self._lbl.pack(side=tk.TOP, fill=tk.X)
        items = inventory.get_items()
        
        self._labels.clear()
        
        for item_name in items:
            if item_name.lower() != 'coin':
                self._draw_item(item_name,
                                len(items[item_name]),
                                ENTITY_COLOURS[items[item_name][0].get_id()])


class ControlsFrame(tk.Frame):
    """
     Inherits from tk.Frame, and displays two buttons (restart and new game),
     as well as a timer of how long the current game has been going for.
    """
    def __init__(self, master: Union[tk.Tk, tk.Frame], **kwargs) -> None:
        """
        Instantiates a ControlsFrame with the buttons displayed at the bottom of interface. 
        """
        super().__init__(
            master,
            width=INVENTORY_WIDTH + MAZE_WIDTH,
            **kwargs
        )
        self._restart_button = ''
        self._new_button = ''
        self._time_label = ''
    
    def draw_timer(self):
        """
        Draws the timer displaying the number of minutes and seconds elapsed
        since the current game began.
        """
        timer_label_title = tk.Label(self, font=TEXT_FONT, text="Timer")
        timer_label_title.grid(row=0, column=7, padx=40)
        self._time_label = tk.Label(self, font=TEXT_FONT, text="0m 0s")
        self._time_label.grid(row=1, column=7, padx=40)


    def set_and_draw_click_restart_callback(self, callback: Callable[str, None]) -> None:
        """
        Draws and sets the callback command for the button to restart the game.
        User returned to start of first level, stats, movecount and stats resets.
        game timer returns to 0.

        Parameters:
            callback: function or method passed to LocalSolver.
        """
        self._restart_button = tk.Button(self,
                                         text="Restart game",
                                         font=TEXT_FONT,
                                         command=callback)
        self._restart_button.grid(row=0, column=0, rowspan=4, padx=40)

    def set_and_draw_click_new_callback(self, callback: Callable[str, None]) -> None:
        """
        Draws and sets the callback command for the toplevel window.
        Toplevel window allows input of file.
        If valid game file, game restarts using game file.
        If invalid game file, informed game file invalid and closes toplevel window.

        Parameters:
            callback: function or method passed to LocalSolver. 
        """
        self._new_button = tk.Button(self,
                                     text="New game",
                                     font=TEXT_FONT,
                                     command=callback)
        self._new_button.grid(row=0, column=2, rowspan=4, padx=40)

    def set_timer(self, seconds):
        """
        Sets the time to the certain minutes and seconds elapsed.

        Parameters:
            seconds: the time in seconds elapsed. 
        """
        minutes = seconds//60
        second = seconds % 60
        self._time_label.config(text=f"{minutes}m {second}s")   


class GraphicalInterface(UserInterface):
    """
    Inherits from UserInterface and manages the overall view and enables event handling. 
    """
    def __init__(self, master: tk.Tk) -> None:
        """
        Instantiates GraphicalInterface class.

        Parameters:
            master: the master frame.
        """
        self._level_view = ''
        self._stats_view = ''
        self._inventory_view = ''
        self._control_view = ''
        self._master = master
        
        self._master.title("Mazerunner")
        title = tk.Label(self._master, text="MazeRunner", font=BANNER_FONT, bg=THEME_COLOUR)
        title.pack(side=tk.TOP, fill=tk.X)
        

    def create_interface(self, dimensions: tuple[int, int]) -> None:
        """
        Creates level view, inventory view, and stats view in master frame for interface.

        Paramters:
            dimensions: (row, column) dimensions of the maze in current level.
        """
        frame = tk.Frame(self._master)

        #determines interface on TASK from constant.py
        if TASK != 2:
            self._level_view = LevelView(frame, dimensions, (MAZE_WIDTH, MAZE_HEIGHT))
        else:
            self._level_view = ImageLevelView(frame, dimensions, (MAZE_WIDTH, MAZE_HEIGHT))
            self._control_view = ControlsFrame(self._master)
            self._control_view.pack(side=tk.BOTTOM, fill=tk.X)
            
        self._level_view.pack(side=tk.LEFT, anchor='ne')
        self._inventory_view = InventoryView(frame)
        self._inventory_view.pack(side=tk.LEFT, anchor='n')
        frame.pack(side=tk.TOP, anchor='w')
        
        self._stats_view = StatsView(self._master, MAZE_WIDTH + INVENTORY_WIDTH)
        self._stats_view.pack(side=tk.TOP)

    def clear_all(self):
        """
        Clears each of the three major componenets.
        """
        self._level_view.clear()
        self._stats_view.clear()
        self._inventory_view.clear()
    
    def set_maze_dimensions(self, dimensions: tuple[int, int]) -> None:
        """
        Updates the dimensions of the maze in the level to dimensions.

        Paramters:
            dimensions: the desired dimensions of the maze in the level. 
        """
        self._level_view.set_dimensions(dimensions)   

    def bind_keypress(self, command: Callable[[tk.Event], None]) -> None:
        """
        Binds the given command to the general key event.

        Parameters:
            command: a function which takes in keypress event and performs different actions
        """
        for nth_motion in range(len(player_motion)):
            self._master.bind(player_motion[nth_motion], lambda press: command(press))

    def set_inventory_callback(self, callback: Callable[[str], None]) -> None:
        """
        Sets the function to be called when an item is clicked in inventory view.

        Parameters:
            callback: the function that performs apply first instance.
        """
        self._inventory_view.set_click_callback(callback)

    def draw_inventory(self, inventory: Inventory) -> None:
        """
        Draws any non-coin inventory items with their quantities,
        and binds the callback for each,
        if a click callback has been set.

        Parameters:
            inventory: the inventory of the player. 
        """
        self._inventory_view.draw_inventory(inventory)

    def draw(self, maze: Maze,
             items: dict[tuple[int, int], Item],
             player_position: tuple[int, int],
             inventory: Inventory,
             player_stats: tuple[int, int, int]) -> None:
        """
        Clears the three major components and redraws them with the new state provided.

        maze: the Maze of the level to be drawn.
        items: the items in the level.
        player_position: the position of the player:
        inventory: the inventory of the player.
        player_stats: the health, hunger, and thirst of the player. 
        """
        self.clear_all()
        
        self._draw_level(maze, items, player_position)
        self._draw_inventory(inventory)
        self._draw_player_stats(player_stats)

    def _draw_inventory(self, inventory: Inventory) -> None:
        """
        Draw both the non-coin items on inventory view and coins on stats view.

        Parameters:
            inventory: the inventory of the player. 
        """
        self._inventory_view.draw_inventory(inventory)
        
        if coin in inventory.get_items():
            self._stats_view.draw_coins(len(inventory.get_items()[coin]))
        else:
            self._stats_view.draw_coins(0)

    def _draw_level(self,
                    maze: Maze,
                    items: dict[tuple[int, int], Item],
                    player_position: tuple[int, int]) -> None:
        """
        Draws the maze of the level with the items and entities. (Levelview)

        Parameters:
            maze: the maze of the level to be drawn.
            items: the collectable items/entities in the maze of the level.
            player_position: the position of the player in the maze.
        """
        self._level_view.set_dimensions(maze.get_dimensions())
        self._level_view.draw(maze.get_tiles(), items, player_position)
        
    def _draw_player_stats(self, player_stats: tuple[int, int, int]) -> None:
        """
        Draws the stats view of the player.

        Parameters:
            player_stats: the health, hunger and thirst of the player. 
        """
        self._stats_view.draw_stats(player_stats)

    def draw_timer(self):
        """
        Draws the time view of the game. 
        """
        self._control_view.draw_timer()
            
    def set_controls_restart_callback(self, callback: Callable[[str], None]) -> None:
        """
        sets the function to be called when the restart button is clicked.

        Parameters:
            callback: the function that restarts the game. 
        """
        self._control_view.set_and_draw_click_restart_callback(callback)

    def set_controls_new_callback(self, callback: Callable[[str], None]) -> None:
        """
        sets the function to be called when the new game button is clicked.

        Parameters:
            callback: the function that creates top window for file enter. 
        """
        self._control_view.set_and_draw_click_new_callback(callback)
            
    def set_timer(self, seconds):
        """
        sets the timer to the specific seconds elapsed.

        Paramaters:
            seconds: the time elapsed in current level in seconds. 
        """
        self._control_view.set_timer(seconds)

         
class GraphicalMazeRunner(MazeRunner):
    """
    Controller class for game.
    Inherits from MazeRunner and allows GraphicalInterface and events genearated by user.
    """
    def __init__(self, game_file: str, root: tk.Tk) -> None:
        """
        Creates a new Graphical MazeRunner Game, with the view inside the given root widget.

        Parameters:
            game_file: the file of the game to be played.
            root: the given root widget.
        """
        self._game_file = game_file
        self._game_storage_initial = game_file
        self._root = root
        self._model = Model(self._game_file)
        self._time = 0
        self._file = ''
        
        
    def _handle_keypress(self, e: tk.Event) -> None:
        """
        Handles keypress.
        If one of 'w', 'a', 's', 'd' pressed, move is attempted.
        If player wins or loses the game with move, informed via messagebox.

        Paramaters:
            e: user event.
        """
        self._handle_move(e.char)
        
        if self._model.has_lost() == True:
            messagebox.showinfo(message = LOSS_MESSAGE)
            self._root.destroy()
        elif self._model.has_won() == True:
            messagebox.showinfo(message = WIN_MESSAGE)
            self._root.destroy()
        else:
            self.redraw()

    def _apply_item(self, item_name: str) -> None:
        """
        Attempts to apply an ite with the given name to the player.

        Parameters:
            item_name: the name of the item to be attempted to applied.
        """
        item = self._model.get_player().get_inventory().remove_item(item_name)
        
        if item is not None:
            item.apply(self._model.get_player())
        self.redraw()


    def play(self) -> None:
        """
        Called to cause gameplay to occur.
        First creates the widgets on the GraphicalInterface,
        binds the keypress handler,
        sets the inventory callback,
        and then redraw to allow the game to begin.
        """
        self._view = GraphicalInterface(self._root)
        self._view.create_interface(self._model.get_level().get_dimensions())
        
        maze = self._model.get_current_maze()
        items = self._model.get_current_items()
        player_position = self._model.get_player().get_position()
        player_stats = self._model.get_player_stats()
        inventory = self._model.get_player_inventory()
        
        self._view.draw(maze,
                        items,
                        player_position,
                        inventory,
                        player_stats)

 
        if TASK == 2:
            self._view.draw_timer()
            self._view.set_controls_restart_callback(self.restart)
            self._view.set_controls_new_callback(self.new_game)
            self.timer()
            self.add_menu()

        self._view.bind_keypress(self._handle_keypress)
        self.redraw()

    def redraw(self):
        """
        Redraws the window with the update stats and information, attempts to apply time. 
        """
        self._redraw()
        self._view.set_inventory_callback(self._apply_item)

    def restart(self):
        """
        function that restarts the game. 
        """
        self._model = Model(self._game_file)
        self._time = 0
        self.redraw()

    def new_game_start(self):
        """
        function that tries to open the given file.
        If successful:
            game file opened with all interfaces,
            time set to 0,
            redrawn and toplevel window destroyed.
        If unsuccessful:
            message box with error message appears,
            and toplevel window destroyed. 
        """
        name = self._file.get()
        
        try:
            self._model = Model(name)
            self._game_file = name
            self._time = 0
            self._redraw()
            self._prompt_file.destroy()
        except:
            messagebox.showinfo(title="Error!", message="An invalid game file!")
            self._prompt_file.destroy()
            
    def new_game(self):
        """
        Opens a toplevel window that allows user to input a file name
        has a button that executes the new_game_start function based on the input. 
        """
        self._prompt_file = tk.Toplevel()
        self._prompt_file.title('prompt_file')
        self._prompt_file.geometry('120x120')
        
        tk.Label(self._prompt_file, text='Enter Game File').pack(pady=20)
        
        self._file = tk.Entry(self._prompt_file)
        self._file.pack()
        
        tk.Button(self._prompt_file, text="Enter", command=self.new_game_start).pack()
        
    def timer(self):
        """
        Displays the number of minutes and seconds elapsed.
        redraws timer per second.
        """
        self._view.set_timer(self._time)
        #increase timer by one second. 
        self._time += 1
        self._root.after(1000, self.timer)

#File menus below:
    def add_menu(self):
        """
        File menu with options to save game, load game, restart game and quit game. 
        """
        menu_bar = tk.Menu(self._root)
        self._root.config(menu=menu_bar)
        file_menu = tk.Menu(menu_bar)
        menu_bar.add_cascade(label="File", menu=file_menu)
        
        file_menu.add_command(label="Save game", command=self.menu_save_game)
        file_menu.add_command(label="Load game", command=self.menu_load_game)
        file_menu.add_command(label="Restart game", command=self.menu_restart)
        file_menu.add_command(label="Quit", command=self.quit)

    def quit(self):
        """
        Prompts player via messagebox to ask whether they are sure to quit.
        If no, do nothing.
        If yes, quit the game.
        """
        msg = "Sure to quit?"
        reply = messagebox.askyesno(type=messagebox.YESNO, title="Warn!", message=msg)
        if reply:
            self._root.destroy()

    def menu_restart(self):
        """
        Restarts the current game, including game time.
        """
        self._model = Model(self._game_file)
        self._time = 0
        self._redraw()

    def menu_load_game(self):
        """
        prompts the user via messagebox for the location of the file to load a game from,
        load the game described in file. 
        """
        load_file = simpledialog.askstring(title="Game file",
                                           prompt="Enter a game filename:")
        
        if not load_file:
            return None
        
        #tries to read saved file.
        try:
            with open(load_file, 'r') as r:
                pass 
        except:
            messagebox.showinfo(title="Error!", message="An invalid game file!")

    def menu_save_game(self):
        """
        prompts the user via message box for the name of the file.
        Saves all necessary information regarding the current game in the file. 
        """
        save_file = simpledialog.askstring(title="Save game",
                                           prompt="Enter a filename:")
        
        if not save_file:
            return None
        
        #gets all the necessary information regarding the maze
        maze = self._model
        file_name = save_file
        level_up = self._model.did_level_up()
        items = self._model.get_level().get_items()
        player_position = self._model.get_player().get_position()
        inventory = self._model.get_player_inventory()
        hp, hunger, thirst = self._model.get_player_stats()
        timer = self._time
        
        #tries to save game
        try:
            with open(save_file, 'w') as f:
                pass 
        except:
            messagebox.showinfo(message="Error!")
                     

    
def play_game(root: tk.Tk):
    """
    Constructs the controller instance using: GAME_FILE constant,
                                              root tk.Tk parameter.
    Causes gameplay to commence.
    Ensure the root window stays open listening for events.

    Parameters:
        root: the created root tk.Tk instance. 
    """
    maze_runner = GraphicalMazeRunner(GAME_FILE, root)
    maze_runner.play()

def main():
    """
    Constructs the root tk.TK instance.
    Calls play_game function passing the newly created root tk.Tk instance.
    """
    root = tk.Tk()
    play_game(root)
    root.mainloop()

    

if __name__ == '__main__':
    main()
