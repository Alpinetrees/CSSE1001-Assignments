from __future__ import annotations
from typing import Optional
from a2_support import UserInterface, TextInterface
from constants import * 

# Replace these <strings> with your name, student number and email address.
__author__ = "<Jingwei Chai>, <47512405>"
__email__ = "<jingwei.chai@uqconnect.edu.au>"

# Before submission, update this tag to reflect the latest version of the
# that you implemented, as per the blackboard changelog. 
__version__ = 1.1


def load_game(filename: str) -> list['Level']:
    """ Reads a game file and creates a list of all the levels in order.
    
    Parameters:
        filename: The path to the game file
    
    Returns:
    A list of all Level instances to play in the game
    """
    levels = []
    with open(filename, 'r') as file:
        for line in file:
            line = line.strip()
            if line.startswith('Maze'):
                _, _, dimensions = line[5:].partition(' - ')
                dimensions = [int(item) for item in dimensions.split()]
                levels.append(Level(dimensions))
            elif len(line) > 0 and len(levels) > 0:
                levels[-1].add_row(line)
    return levels


#Global variables
ENTITY = "E"
EMPTIED_OBJECT = []
ACCEPTABLE_TILES = [LAVA, WALL, EMPTY, DOOR]
ACCEPTABLE_TILES_ENTITIES = [LAVA, WALL, EMPTY, DOOR, ABSTRACT_TILE,
                             PLAYER, FOOD, COIN, DYNAMIC_ENTITY,
                             POTION, HONEY, APPLE, WATER, ITEM]
ABSTRACT_OR_NONENTITY = [ABSTRACT_TILE, DYNAMIC_ENTITY, ITEM, FOOD, LAVA, WALL, EMPTY, DOOR]
ACCEPTABLE_ENTITIES = [COIN, POTION, HONEY, APPLE, WATER, PLAYER]
COLLECTABLE_ITEMS = [COIN, POTION, HONEY, APPLE, WATER]
ITEM_NAME_DICT = {'Potion': 'Potion',
                  'Honey': 'Honey',
                  'Apple': 'Apple',
                  'Water': 'Water'
                  }
FIFTH_MOVE = 5
MOVEMENT_DAMAGE = 1
MIN_THIRST_HUNGER = 0


#class and subsequent methods start here:

class Tile():
    """ Abstract class that represents the floor for a position"""
    def __init__(self):
        """
        Initialise a Tile instance:
        """
        self._is_blocking = False
        self._damage = 0
        self._get_id = ABSTRACT_TILE
        self._name = "Tile()"
        
    def is_blocking(self) -> bool:
        """
        (bool) Returns the status of blocking.
        """
        return self._is_blocking
    
    def damage(self) -> int:
        """
        (int) Returns the damage of tile. 
        """
        return self._damage

    def get_id(self) -> str:
        """
        (str) Returns the single character ID of tile.
        """
        return self._get_id

    def __str__(self) -> str:
        """
        (str) Returns the string representation of tile.
        """
        return self._get_id

    def __repr__(self) -> str:
        """
        (str) Returns the string required to create new identical instance of class.
        """
        return "{}".format(self._name)
    
class Wall(Tile):
    """ A tile that is blocking player (A Dynamic Entity) """
    def __init__(self):
        """
        Creates a Wall tile.
        """
        super().__init__()
        self._is_blocking = True
        self._get_id = WALL
        self._name = "Wall()"

class Empty(Tile):
    """ A tile that player can move across with no damage"""
    def __init__(self):
        """
        Creates an Empty tile.
        """
        super().__init__()
        self._get_id = EMPTY
        self._name = "Empty()"
        
class Lava(Tile):
    """ A tile that player can move across with damage of 5"""
    def __init__(self):
        """
        Creates a Lava tile. 
        """
        super().__init__()
        self._damage = LAVA_DAMAGE
        self._get_id = LAVA
        self._name = "Lava()"

class Door(Tile):
    """
    A tile that is blocking player while blocking,
    A tile that player can move across with no damage if unlocked.
    """ 
    def __init__(self):
        """
        Creates a Door tile. 
        """
        super().__init__()
        self._is_blocking = True
        self._get_id = DOOR
        self._name = "Door()"

    def unlock(self):
        """
        Unlocks (sets to not blocking) the Door tile.
        """
        self._is_blocking = False
        self._get_id = EMPTY

#END OF TILE PART

class Entity():
    """ Abstract class providing functionality for all entities in game"""
    def __init__(self, position: tuple[int, int]) -> None:
        """
        Creates an Entity object.

        Parameters:
            position (tuple[int, int]): The position of Entity object.
        """
        self._row, self._column = position[0], position[1]
        self._get_id = ENTITY
        self._name = "Entity"

    def get_position(self) -> tuple[int, int]:
        """
        Returns:
        (tuple[int, int]) the position of entity.
        """
        return (self._row, self._column)

    def get_name(self) -> str:
        """
        Returns:
        (str) the entity's name of class.
        """
        return self._name

    def get_id(self) -> str:
        """
        Returns:
        (str) the single character ID of entity.
        """
        return self._get_id

    def __str__(self) -> str:
        """
        Returns:
        (str) the string representation (ID) of entity.
        """
        return self._get_id

    def __repr__(self) -> str:
        """
        Returns: 
        (str) the string required to create new identical instance of class.
        """
        return "{}({})".format(self._name, (self._row, self._column))
        
    
class DynamicEntity(Entity):
    """
    Abstract class inherited from Entity class.
    Provides base functionality for Entities that are dynamic (movable)
    """
    def __init__(self, position: tuple[int, int]) -> None:
        """
        Creates a DynamicEntity object.

        Parameters:
            position (tuple[int, int]): The position of DynamicEntity object.
        """
        self._row, self._column = position[0], position[1]
        self._get_id = DYNAMIC_ENTITY
        self._name = "DynamicEntity"

    def set_position(self, new_position: tuple[int, int]) -> None:
        """
        Sets DynamicEntity to a new position:

        Parameters:
            new_position (tuple[int, int]): The new position of DynamicEntity object.

        (None) Does not return a value
        """
        self._row, self._column = new_position[0], new_position[1]

class Player(DynamicEntity):
    """
    A DybamicEntity controlled by user that can be moved to other position.
    Initial health 100, thirst, hunger 0, has a player inventory.
    """
    def __init__(self, position: tuple[int, int]):
        """
        Creates a Player DynamicEntity.

        Parameters:
            position (tuple[int, int]): The position of the player.
        """
        self._row, self._column = position[0], position[1]
        self._health = MAX_HEALTH 
        self._hunger = MIN_THIRST_HUNGER
        self._thirst = MIN_THIRST_HUNGER
        self._storage = []
        self._inventory = ''
        self._name = "Player"

    def get_hunger(self) -> int:
        """
        Returns:
        (int) the current hunger of player.
        """
        return self._hunger

    def get_thirst(self) -> int:
        """
        Returns:
        (int) the current thirst of player.
        """
        return self._thirst

    def get_health(self) -> int:
        """
        Returns:
        (int) the current health of player.
        """
        return self._health

    def change_hunger(self, amount: int) -> None:
        """
        Changes the hunger of the player.
        If changed hunger below minimum hunger, hunger changes back to minimum hunger.

        Parameters:
            amount (int): the amount of change.

        Returns:
        (None) does not return a value.
        """
        self._hunger += amount
        if self._hunger < MIN_THIRST_HUNGER:
            self._hunger -= self._hunger 

    def change_thirst(self, amount: int) -> None:
        """
        Changes the thirst of the player.
        If changed thirst below minimum thirst, thirst changes back to minimum tirst.

        Parameters:
            amount (int): the amount of change.

        Returns:
        (None) does not return a value.
        """
        self._thirst += amount
        if self._thirst < MIN_THIRST_HUNGER:
            self._thirst -= self._thirst

    def change_health(self, amount: int) -> None:
        """
        Changes the health of the player.
        If changed health above maximum health, health changes back to maximum health.

        Parameters:
            amount (int): the amount of change.

        Returns:
        (None) does not return a value.
        """
        self._health += amount
        if self._health > MAX_HEALTH:
            self._health -= (self._health - MAX_HEALTH)

    def get_inventory(self) -> Inventory:
        """
        Creates an inventory if inventory is empty, provides inventory if inventory exists. 

        Returns:
        (Object) the inventory of the player.
        """
        if self._inventory == '':
            self._inventory = Inventory(self._storage)
            return self._inventory
        return self._inventory 
        
    def add_item(self, item: Item) -> None:
        """
        Adds item to the player's inventory.

        Parameters:
            item (Item): the item (Item) to be added.

        Returns:
        (None) does not return a value
        """
        if self._inventory == '':
            self._storage.append(item)
        else:
            self._inventory.add_item(item)
        
class Item(Entity):
    """ Subclass of Entity that provides base functionality for items (further subclasses) in game"""
    def __init__(self, position: tuple[int, int]) -> None:
        """
        Creates an Item Entity.

        Parameters:
            position (tuple[int, int]: the position of the Item.
        """
        self._row, self._column = position[0], position[1]
        self._get_id = ITEM
        self._name = 'Item'

    def apply(self, player: Player) -> None:
        """
        Applies the item effect (if any) to player.
        Raises NotImplementedError as apply method is defined in the subclasses of Item
        """
        raise NotImplementedError 

        
class Potion(Item):
    """ An item, when applied, increases player health by 20"""
    def __init__(self, position: tuple[int, int]):
        """
        Creates a potion item.

        Parameters:
            position (tuple[int, int]): the position of potion.
        """
        self._row, self._column = position[0], position[1]
        self._name = 'Potion'
        self._get_id = POTION

    def apply(self, player: Player):
        """
        Increases the player's health by 20 (POTION_AMOUNT).

        Parameters:
            player (Player): the player to be affected. 

        Returns:
        (None) does not return a value
        """
        player.change_health(POTION_AMOUNT)

class Coin(Item):
    """An item, with no effect to player, but collected in player inventory to surpass current level"""
    def __init__(self, position: tuple[int, int]):
        """
        Creates a coin item.
        
        Parameters:
            position (tuple[int, int]): the position of coin.
        """
        self._row, self._column = position[0], position[1]
        self._name = 'Coin'
        self._get_id = COIN

    def apply(self, player: Player):
        """
        Coin with no effect to player, act of collection is not implemented with this class.

        Parameters:
            player (Player): the player to be affected.

        Returns:
        (None) does not return a value.
        """
        None
    

class Water(Item):
    """ An item, when applied, decreases player thirst by 5"""
    def __init__(self, position: tuple[int, int]):
        """
        Creates a water item.
        
        Parameters:
            position (tuple[int, int]): the position of water.
        """
        self._row, self._column = position[0], position[1]
        self._name = "Water"
        self._get_id = WATER

    def apply(self, player: Player):
        """
        Decreases the player's thirst by 5 (WATER_AMOUNT).

        Parameters:
            player (Player): the player to be affected. 

        Returns:
        (None) does not return a value
        """
        player.change_thirst(WATER_AMOUNT)

class Food(Item):
    """
    Abstract class, defining the base functionality of Food subclasses.
    Food subclasses, when applied, decreases player hunger by certain amount (depends on type)
    """
    def __init__(self, position: tuple[int, int]):
        """
        Creates a food item.

        Parameters:
            position (tuple[int, int]): the position of food. 
        """
        self._row, self._column = position[0], position[1]
        self._name = "Food"
        self._get_id = FOOD
        self._amount = 0 

    def apply(self, player: Player):
        """
        Decreases the player's hunger by certain amount (self._amount)
        Food, the abstract class, does not change player hunger.

        Parameters:
            player (Player): the player to be affected.

        Returns:
        (None) does not return a value
        """
        player.change_hunger(self._amount)

class Apple(Food):
    """A food, when applied, decreases the players' hunger by 1 (APPLE_AMOUNT)"""
    def __init__(self, position: tuple[int, int]):
        """
        Creates a Apple food.

        Parameters:
            position (tuple[int, int]): the position of food
        """
        self._row, self._column = position[0], position[1]
        self._name = "Apple"
        self._get_id = APPLE
        self._amount = APPLE_AMOUNT

class Honey(Food):
    """A food, when applied, decreases the players' hunger by 5 (HONEY_AMOUNT)"""
    def __init__(self, position: tuple[int, int]):
        """
        Creates a Honey food.

        Parameters:
            position (tuple[int, int]): the position of food
        """
        self._row, self._column = position[0], position[1]
        self._name = "Honey"
        self._get_id = HONEY
        self._amount = HONEY_AMOUNT

#End of Entity Part 

class Inventory():
    """ A class that contains and manages collection of items """
    def __init__(self, initial_items: Optional[list[Item,...]] = None) -> None:
        """
        Sets up inventory.
        If no initial items provided, inventory starts as empty dictionary.
        Otherwise, initial dictionary set up from initial_items list mapping item names to list of item instances.

        Parameters:
            initial_items (Optional[list[Item, ...]]): the initial items for setting up inventory.
        """
        self._storage = {}
        if initial_items is not None:
            for item in initial_items:
                self.add_item(item)
        self._initial_items = initial_items
            
    def add_item(self, item: Item):
        """
        Adds item to inventory.
        If inventory does not already contain item key, dictionary creates key.
        Else, adds to existing key.

        Parameters:
            item (Item): the item to be added.

        Returns:
        (None) does not return a value
        """
        if self._storage.get(item._name) != None:
            temporary_lst = self._storage.get(item._name)
            temporary_lst += [(item)] 
            self._storage[item._name] = temporary_lst
        else:
            self._storage[item._name] = [item] 

    def get_items(self) -> dict[str, list[Item, ...]]:
        """
        Returns:
            (dict[str, list[Item, ...]]) the inventory dictionary.
        """
        return self._storage 
    
    def remove_item(self, item_name: str) -> Optional[Item]:
        """
        Removes the first instance of the item of item_name from inventory.
        If the item is the last of its type (ie. Potion, Coin...) item key is removed.

        Parameters:
            item_name (str): the name of the item to be removed.

        Returns:
            if item exists:
            (Object) the item instance removed.
            else:
            (None) does not return a value.
        """
        if self._storage.get(item_name) != None:
            temporary_lst = self._storage.get(item_name)
            self._item_removed = temporary_lst[0]
            temporary_lst.remove(temporary_lst[0])
            self._storage[item_name] = temporary_lst
            if self._storage[item_name] == EMPTIED_OBJECT:
                self._storage.pop(item_name, None)
            return self._item_removed
        return None 
        
    def __str__(self) -> str:
        """
        Returns:
        (str) string containg quantites of items in inventory.
        """
        self._result = ''
        for elements in self._storage:
            number_of_instances = 0
            number_of_instances += len(self._storage[elements])
            self._result += (f"{elements}: {number_of_instances}\n")
            self._result_final = self._result.strip()
        return self._result_final
        
    def __repr__(self) -> str:
        """
        Returns: 
        (str) the string required to create new instance of Inventory containing same items.
        """
        self._initial_items.sort(key=lambda x: x._name, reverse=True)
        return "Inventory(initial_items={}".format(self._initial_items)

#End of Inventory Part
    
class Maze():
    """
    A class that represents the space in which a level takes palce.
    Disregards entity position, only accounts the tiles and dimension.
    """
    def __init__(self, dimensions: tuple[int, int]) -> None:
        """
        Creates empty maze with given dimension.

        Parameters:
            dimensions (tuple[int, int]): the dimensions of the maze.
        """
        self._number_rows, self._number_columns = dimensions[0], dimensions[1]
        self._name = "Maze"
        self._maze_structure = []
        self._list_instances = []
        self._result_final = ''
        
    def get_dimensions(self):
        """
        Returns:
        (tuple) the number of rows and columns (#rows, #columns) in the maze.
        """
        return (self._number_rows, self._number_columns)

    def add_row(self, row: str) -> None:
        """
        Adds row of tile to maze.
        row must not violate dimensions of maze.

        Parameters:
            row (str): string of row to be added. characater is Tile ID.

        Returns:
            if violates dimensions:
            (bool) False
        """
        listed_row = list(row)
        constructing_row = []
        #checking precondition
        if len(row) != self._number_columns or len(self._maze_structure) == self._number_rows:
            return False
        for elements in listed_row:
            if elements == " ":
                constructing_row += EMPTY
            elif elements not in ACCEPTABLE_TILES:
                constructing_row += EMPTY
            else:
                constructing_row += elements
        self._maze_structure += [constructing_row]
        
    def get_tiles(self) -> list[list[Tile]]:
        """
        Returns:
        (list[list[Tile]]) the Tile instances in this maze.
        """
        self._list_instances = []
        #iterates over structure to determine instances
        for element in self._maze_structure:
            for tiles in element:
                if tiles == EMPTY:
                    self._list_instances.append(Empty())
                elif tiles == DOOR:
                    self._list_instances.append(Door())
                elif tiles == LAVA:
                    self._list_instances.append(Lava())
                else:
                    self._list_instances.append(Wall())
        self._list_instances = [self._list_instances[x:x+self._number_columns]
                                for x in range(0, len(self._list_instances),
                                               self._number_columns)]
        return self._list_instances
        
    def unlock_door(self) -> None:
        """
        Unlocks doors in maze.

        Returns:
        (None) does not return a value.
        """
        unlocked_doors = []
        for tiles in self._maze_structure:
            tiles = list(map(lambda x: x.replace(DOOR, EMPTY),
                                tiles))
            unlocked_doors += [tiles]
        self._maze_structure = unlocked_doors
                    

    def get_tile(self, position: tuple[int, int]) -> Tile:
        """
        returns tile instance.
        
        Parameters:
            position (tuple[int, int]): the position of tile in interst.

        Returns:
        (Tile) the Tile instance at give position.
        """
        self._list_instances = Maze.get_tiles(self)
        check_row = self._list_instances[position[0]]
        tile_result = check_row[position[1]]
        return tile_result
    
    def __str__(self) -> str:
        """
        Returns:
        (str) the string representation of maze.
        Each line in output is row in maze.
        Each instance is represented by its ID.
        """
        self._result = ''
        for elements in self._maze_structure:
            temporary_storage_string = "".join(elements)
            self._result += (f"{temporary_storage_string}\n")
            self._result_final = self._result.strip()
        return self._result_final   

    def __repr__(self) -> str:
        """
        Returns:
        (str) string required to create new instance of Maze with same dimensions.
        """
        return "{}({})".format(self._name, (self._number_rows,
                                            self._number_columns))

#End of Maze Part
    
class Level():
    """A class that creates level instance, keeps track of maze and non-player entities for single level"""
    def __init__(self, dimensions: tuple[int, int]) -> None:
        """
        Creates a new level with empty maze. Set up initially with no items or player.

        Parameters:
            dimensions (tuple[int, int]): the dimension of the maze. 
        """
        self._number_rows, self._number_columns = dimensions[0], dimensions[1]
        self._name = "Level"
        self._level_structure = []
        self._item_dict = {}
        self._row = ''
        self._maze = ''
        self._player_start = None
        self._position_reset = None 
        
    def get_maze(self) -> Maze:
        """
        Returns:
        (Maze) the maze instance for this level. 
        """
        self._maze = Maze((self._number_rows, self._number_columns))
        self._maze._maze_structure_initial = self._level_structure
        self._maze._maze_structure = []
        #iterates over the tiles to get maze 
        for rows in self._maze._maze_structure_initial:
            for element_column in rows:
                if element_column in ACCEPTABLE_ENTITIES:
                    self._maze._maze_structure += [EMPTY]
                else:
                    self._maze._maze_structure += [element_column]
        #separating into appropriate rows
        self._maze._maze_structure = [self._maze._maze_structure[x:x+self._number_columns]
                                for x in range(0, len(self._maze._maze_structure),
                                               self._number_columns)]
        return self._maze

    def attempt_unlock_door(self) -> None:
        """
        attempts to unlock doors within maze if no coin is remaining.

        Returns:
        (None) does not return a value.
        """
        door_open = True
        self._level_structure_temporary = []
        for elements in self._level_structure:
            if COIN in elements:
                door_open = False
        if door_open == True:
            for elements in self._level_structure:
                elements = [Tiles.replace(DOOR, EMPTY) for Tiles in elements]
                self._level_structure_temporary.append(elements)
            self._level_structure = self._level_structure_temporary
            return self._level_structure
        
    def add_row(self, row: str) -> None:
        """
        adds tiles and entities from row to level.
        
        Parameters:
            row (str): the string containing Tile IDs and Entitie IDs.

        Returns:
        (None) Does not return a value.
        """
        self._row = row
        self._listed_row = list(row)
        constructing_row = []
        for elements in self._listed_row:
            if elements == " ":
                constructing_row += EMPTY
            elif elements not in ACCEPTABLE_TILES_ENTITIES:
                constructing_row += EMPTY
            else:
                constructing_row += elements
        self._level_structure += [constructing_row]

    def add_entity(self, position: tuple[int, int], entity_id: str) -> None:
        """
        Adds new entity(type dependent on entity_id) on give position to this level.
        If no item exist on position, entity_id item stored in position.
        If item already exsit on position, item replaced by entity_id item.

        Parameters:
            position (tuple[int, int]): the position the entity to be added.
            entity_id (str): the ID of the item (Entity) to be added.

        Returns:
        (None) does not return a value
        """
        temporary_list = []
        if len(self._level_structure) != self._number_rows:
            for no_times_append in range(self._number_rows):
                temporary_list.append(self._number_columns*[EMPTY])
            self._level_structure = temporary_list
        if entity_id != PLAYER and entity_id != ACCEPTABLE_TILES:
            self._level_structure[position[0]][position[1]] = entity_id
        
    def get_dimensions(self) -> tuple[int, int]:
        """
        Returns:
        (tuple[int, int]) the rows and columns (#row, #columns) of the level maze.
        """
        return (self._number_rows, self._number_columns)

    def get_items(self) -> dict[tuple[int, int], Item]:
        """
        Returns:
        (dict[tuple[int, int]), Item) the mapping from position to Item at position for all items in level.
        """
        #iterates over each inidividual tiles and adds into dictionary
        for x, rows in enumerate(self._level_structure):
            for y, element_columns in enumerate(rows):
                #does not include non items and abstract or unused items and player
                if element_columns not in ABSTRACT_OR_NONENTITY and element_columns != PLAYER:
                    if element_columns == COIN:
                        self._item_dict[(x, y)] = Coin((x, y))
                    elif element_columns == POTION:
                        self._item_dict[(x, y)] = Potion((x, y))
                    elif element_columns == HONEY:
                        self._item_dict[(x, y)] = Honey((x, y))
                    elif element_columns == APPLE:
                        self._item_dict[(x, y)] = Apple((x, y))
                    else:
                        self._item_dict[(x, y)] = Water((x, y))
        return self._item_dict


    def remove_item(self, position: tuple[int, int]) -> None:
        """
        Deletes item from position.
        Precondition: item must exist on position.

        Parameters:
            position (tuple[int, int]): the position in which the item will be removed.

        Returns:
        (None) does not return a value.
        """
        if self._level_structure[position[0]][position[1]] in ACCEPTABLE_TILES_ENTITIES:
            self._level_structure[position[0]][position[1]] = EMPTY
        if (position[0], position[1]) in self._item_dict:
            self._item_dict.pop((position[0], position[1]))
        
    def add_player_start(self, position: tuple[int, int]) -> None:
        """
        Adds start position for player in the level.

        Parameters:
            position (tuple[int, int]): the start position of player.

        Returns:
        (None) does not return a value.
        """
        temporary_list = []
        if len(self._level_structure) != self._number_rows:
            for no_times_append in range(self._number_rows):
                temporary_list.append(self._number_columns*[EMPTY])
            self._level_structure = temporary_list
            self._level_structure[position[0]][position[1]] = PLAYER
        self._level_structure[position[0]][position[1]] = PLAYER

    def get_player_start(self) -> Optional[tuple[int, int]]:
        """
        Returns:
        (Optional[tuple[int, int]]) the player starting position of level, if there exists one. 
        """
        for x, rows in enumerate(self._level_structure):
            for y, element_columns in enumerate(rows):
                if element_columns == PLAYER:
                    self._player_start = (x, y)
                    return (x, y)

    def __str__(self) -> str:
        """
        Returns:
        (str) a string representation of the level.
        """
        self._result = ''
        for elements in self._level_structure:
            temporary_storage_string = "".join(elements)
            self._result += (f"{temporary_storage_string}\n")
        self._result = self._result.strip()
        self._item_dict = self.get_items()
        self._player_start = self.get_player_start()
        for elements in ACCEPTABLE_ENTITIES:
            self._result = self._result.replace(elements, EMPTY)
        self._result = f"Maze: {self._result}\nItems: {self._item_dict}\nPlayer start: {self._player_start}"
        return self._result
    
    def __repr__(self) -> str:
        """
        Returns:
        (str) string required to create new instance of Level with same dimensions.
        """
        return "{}({})".format(self._name, (self._number_rows, self._number_columns))

#End of Level Part

class Model():
    """
    A class that controller uses to mutates the game state.
    Keeps track of a Player, multiple level instances.
    Provides interface through which the controller can request information regarding game state.
    Provides interface through which the controller can change the game state.
    """
    def __init__(self, game_file: str) -> None:
        """
        Sets up model instance from game_gile.

        Parameters
            game_file (str): Path to file containting the game information.
        """
        self._file = game_file 
        self._model = load_game(game_file)
        self._nth_maze = 0
        self._previous_maze = self._nth_maze - 1 
        self._name = "Model"
        self._player = None
        self._move_counter = 0
        self._player_location = self._model[self._nth_maze].get_player_start()
        self._maze = self._model[self._nth_maze].get_maze()
        self._level = self._model[self._nth_maze]
        self._inventory = None
        self._won = False 

    def has_won(self) -> bool:
        """
        Determines if the game has been won.
        Game won if all levels surpassed.
        
        Returns:
            if won:
            (bool) True
            else:
            (bool) False 
        """
        if self._nth_maze > (len(self._model)-1):
            return True
        return False 

    def has_lost(self) -> bool:
        """
        Determimes if the game has been lost.
        Game lost if player status not within desirable limit. ie. HP too low, hunger or hunger too high.

        Returns:
            if lost:
            (bool) True
            else:
            (bool) False 
        """
        if self._player == None:
            self.get_player()
        if self._player.get_health() <= 0 or self._player.get_thirst() >= MAX_THIRST or self._player.get_hunger() >= MAX_HUNGER:
            return True
        return False 

    def get_level(self) -> Level:
        """
        Returns:
        (Level) returns the current level.
        """
        if self.has_won() == False and self.has_lost() == False:
            self._level = self._model[self._nth_maze]
            return self._level

    def level_up(self) -> None:
        """
        Changes the level to next level in game.
        If no more level, has_won() == True.

        Returns:
        (None) does not return a value.
        """
        self._nth_maze += 1
        if self._nth_maze > (len(self._model)-1):
            self.has_won()
        #try except code to determine whether the game has been won. 
        try:
            self._maze = self._model[self._nth_maze].get_maze()
            self._player_location = self._model[self._nth_maze].get_player_start()
            self._level = self._model[self._nth_maze]
        except IndexError:
            self.has_won()

    def did_level_up(self) -> bool:
        """
        Returns:
            if leveled up:
            (bool) True
            else:
            (bool) False 
        """
        if self._nth_maze > (self._previous_maze + 1):
            self._previous_maze += 1 
            return True
        return False  

    def move_player(self, delta: tuple[int, int]) -> None:
        """
        Tries to move player by requested change (delta).
        Levels up player if player surpasses current level.
        If player did not level up, and tile moved into not blocking:
            player hunger, thirst, health updates.
            player position updates.
            attempts collect item.

        Parameters:
            delta (tuple[int, int]): change requested by controller

        Returns:
        (None) does not return a value
        """
        #create player, inventory if none exists
        if self._player == None:
            self.get_player()
        if self._inventory == []:
            self._inventory = self._player.get_inventory()

        #calculates level up position, levels up in position
        if self.has_won() == False:
            for rows in range(len(self.get_level().get_maze().get_tiles())):
                for columns in range(len(self.get_level().get_maze().get_tiles()[rows])):
                     if str(self.get_level().get_maze().get_tile((rows, columns))) == DOOR:
                         self._to_level_up = ((rows, columns))
        if self._player_location == self._to_level_up:
            self.level_up()

        #Upon leveling up, if game won, player remains in maze until winning message prompted
        if self.has_won() == False:
            #determines whether tile blocking and player position due to whether level up occured
            if self.did_level_up() == False:
                self._player_location = self._player.get_position()
                self._position_reset = False
            else:
                self._position_reset = True
            self._future_position = tuple(x+y for x, y in zip(self._player_location, delta))
            if self._maze.get_tiles()[self._future_position[0]][self._future_position[1]].is_blocking():
                delta = (0, 0)
            if self._position_reset == False:
                self._player_location = tuple(x+y for x, y in zip(self._player_location, delta))
            self._maze = self._level.get_maze()
            self._player.set_position(self._player_location)

            #if player position did not reset, player continues to take damage in current maze.
            if self._position_reset == False:
                if (abs(delta[0]) + abs(delta[1])) > 0:
                    if str(self._level.get_maze().get_tile((self._player_location))) == LAVA:
                        self._player.change_health(-(LAVA_DAMAGE + MOVEMENT_DAMAGE))
                    else:
                        self._player.change_health(-MOVEMENT_DAMAGE)
                self._move_counter += (abs(delta[0]) + abs(delta[1]))
            if self._move_counter == FIFTH_MOVE:
                self._player.change_hunger(MOVEMENT_DAMAGE)
                self._player.change_thirst(MOVEMENT_DAMAGE)
                self._move_counter -= FIFTH_MOVE
            self.attempt_collect_item(self._player_location)
        else:
            self._nth_maze -= 1
            self._won = True

    def attempt_collect_item(self, position: tuple[int, int]) -> None:
        """
        Collects item if one exists on give position.
        Unlocks door if all coin collected.

        Parameters:
            position (tuple[int, int]): the position of item to be collected.

        Returns:
        (None) does not return a value.
        """
        self._row, self._column = self._player_location[0], self._player_location[1]
        if (self._row, self._column) in self._level.get_items():
            self.get_player().add_item(self._level.get_items()[(self._row, self._column)])
            self._level.remove_item((self._row, self._column))
        if self._position_reset == False:
            self._level.attempt_unlock_door()
            
    def get_player(self) -> Player:
        """
        Returns:
        (Player) the player in game. If no player in game, player created.
        """
        if self._player == None:
            self._player = Player(self._player_location)
        if self.did_level_up() == True:
            self._player = Player(self._model[self._nth_maze].get_player_start())
            return self._player
        return self._player 

    def get_player_stats(self) -> tuple[int, int, int]:
        """
        Returns:
        (tuple[int, int, int]) the stats regarding health, hunger and thirst of player.
        """
        return (self._player.get_health(), self._player.get_hunger(), self._player.get_thirst())

    def get_player_inventory(self) -> Inventory:
        """
        Returns:
        (Inventory) the player's inventory
        """
        self._inventory = self.get_player().get_inventory()
        return self._inventory

    def get_current_maze(self) -> Maze:
        """
        Returns:
        (Maze) the current Maze for level
        """
        return self._level.get_maze() 

    def get_current_items(self) -> dict[tuple[int, int], Item]:
        """
        Returns:
        (dict[tuple[int, int]) the dictionary maping positions to item that currently existat position on maze.
        """
        return self._level.get_items()

    def __str__(self) -> str:
        """
        Returns:
        (str) string required to create new instance of Model with same game to construct self.
        """
        return "{}('{}')".format(self._name, self._file)

    def __repr__(self) -> str:
        """
        same function as __str__
        
        Returns:
        (str) string required to create new instance of Model with same game to construct self.
        """
        return self.__str__()

#End of Model Part

class MazeRunner():
    """
    The controller class maintaining instances of model and view.
    It collects user input and faciliates communication between model and view.
    """
    def __init__(self, game_file: str, view: UserInterface) -> None:
        """
        Creates a MazeRunner instance with given view
        Instantiates new Model using game_file

        Parameters:
            game_file (str): Path to file containting the game information.
            view: the UserInterface of the game
        """
        self._game_file = game_file
        self._view = view
        self._model = Model(self._game_file)
        self._interface = UserInterface
        self._text_interface = TextInterface()
        
    def play(self) -> None:
        """
        Executes game until win/loss occurs.
        Method run as file runs and user inputs appropriate game_file and view.
        prints winning and losing message upon termination. 

        Returns:
        (None) Does not return a value. 
        """
        self.display()
        self._user_input = str(input("\nEnter a move: "))
        game_on = True
        while game_on:
            #moves player, checks win/loss status
            if self._user_input in MOVE_DELTAS:
                self.player_movement()
                self._model.has_lost()
                if self._model.has_lost() == True:
                    game_on = False
                    print(LOSS_MESSAGE)
                    break
                if self._model._won == True:
                    game_on = False 
                    print(WIN_MESSAGE)
                    break
                self.display()
                self.prompt_user()
            #applies potion effect 
            elif self._user_input in [f"i Potion", f"i Honey", f"i Apple", f"i Water"]:
                self.item_usage()
            #invalid input
            else:
                self.prompt_user()
                
    def display(self) -> None:
        """
        The display of the maze.
        Draws the maze when method is called.

        Returns:
        (None) does not return a value. 
        """
        self._text_interface._draw_level(self._model.get_current_maze(),
                                         self._model.get_current_items(),
                                         self._model._player_location)
        self._text_interface._draw_inventory(self._model.get_player_inventory())
        self._text_interface._draw_player_stats(self._model.get_player_stats())

    def prompt_user(self) -> str:
        """
        collects user input when method is called.

        Returns:
        (str) the string of user input stored in self._user_input
        """
        self._user_input = str(input("\nEnter a move: "))
        return self._user_input

    def player_movement(self) -> None:
        """
        If the tile is unblocking and game has not been won/loss and input appropriate:
        Moves the player to the certain location inputted by user when called.

        Returns:
        (None) does not return a value
        """
        self._model.move_player(MOVE_DELTAS[self._user_input])

    def item_usage(self) -> None:
        """
        If the user inputs appropriate:
        Applies the effect of the item to player, i.e potion adding health, when called.

        Returns:
        (None) does not return a value. 
        """
        if ITEM_NAME_DICT[str(self._user_input)[2:]] in self._model.get_player_inventory().get_items():
            self._model.get_player_inventory().get_items()[ITEM_NAME_DICT[str(self._user_input)[2:]]][0].apply(self._model.get_player())
            self._model.get_player_inventory().remove_item(ITEM_NAME_DICT[str(self._user_input)[2:]])
            self.display()
        else:
            print(ITEM_UNAVAILABLE_MESSAGE)
            self.display()
        self._user_input = str(input("\nEnter a move: "))
                
#End of MazeRunner Part

def main():
    """
    The point of execution for program
    Executes as soon as the program ran.
    collects user input as game_file and instantiates MazeRunner
    """
    game_file = str(input("Enter game file: "))
    MazeRunner(game_file, UserInterface).play()
    
if __name__ == '__main__':
    """
    boilerplate code protecing users from invoking script.
    """
    main()

#End of Program
