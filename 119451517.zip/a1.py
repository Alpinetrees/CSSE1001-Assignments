"""
Wordle
Assignment 1
Semester 1, 2022
CSSE1001/CSSE7030
"""

from string import ascii_lowercase
from typing import Optional

from a1_support import (
    load_words,
    choose_word,
    VOCAB_FILE,
    ANSWERS_FILE,
    CORRECT,
    MISPLACED,
    INCORRECT,
    UNSEEN,
)


# Replace these <strings> with your name, student number and email address.
__author__ = "<Jingwei Chai>, <47512405>"
__email__ = "<jingwei.chai@uqconnect.edu.au>"


# Add your functions here

length_of_words = 6

def has_won(bs: str, cs: str) -> int:
    """
    Returns True if the guess is the answer
    """
    for letters in bs:
        for letter in cs:
            #Checking each letter
            if letters == letter:
                return(True)
            else:
                return(False)

def has_lost(guess_number: int) -> bool:
    """
    Returns True if the guess_number is greater than the length_of_words
    """
    if guess_number >= length_of_words:
        return(True)
    else:
        return(False)

def remove_word(words: tuple[str, ...], word: str) -> tuple[str, ...]:
    """
    removes the word from words
    """
    list_words = list(words)
    list_words.remove(word)
    end_result = tuple(list_words)
    return end_result

def prompt_user(guess_number: int, words: tuple[str, ...]) -> str:
    """
    Prompts the user to enter a guess
    Checks if the user_guess is correct or not 
    """
    equal = True
    while equal:
        user_guess = input(f"Enter guess {guess_number}: ")
        if user_guess in ("Q", "q", "K", "k", "H", "h"):
            return(user_guess.lower())
        elif len(user_guess) != 6: 
            print("Invalid! Guess must be of length 6")
        elif user_guess not in words:
            print("Invalid! Unknown word")
        else:
            return(user_guess)
    equal = False 


def process_guess(guess: str, answer: str) -> str:
    """
    determines whether the letters are correct, misplaced or incorrect
    """
    result = ""
    no_duplication = ""
    for letters in guess:
        #replaces any duplicate letter with a space
        if letters not in no_duplication:
            no_duplication += letters
        else:
            no_duplication += " "

    for position_of_letter in range(length_of_words):
        #process the guess and returns green if correct, yellow if misplaced, and black if incorrect
        if no_duplication[position_of_letter] == answer[position_of_letter]:
            result += CORRECT 
        elif no_duplication[position_of_letter] in answer:
            result += MISPLACED  
        else:
            result += INCORRECT
    return result 


def update_history(history: tuple[tuple[str, str], ...], guess: str, answer: str) -> tuple[tuple[str, str],...]:
    """
    updates the history of the gameplay
    """
    updated_history = []
    updated_history = list(history) + [(guess, process_guess(guess, answer))]
    updated_history = tuple(updated_history)
    return updated_history

def print_history(history: tuple[tuple[str, str], ...]) -> None:
    """
    prints out the history of the gameplay
    """
    Guess_number = 1
    required_formatting_dashes = 15*"-"
    for number_of_tuples in history:
        #formats the blocks of CORRECT/MISPLACED/INCORRECT below the letter
        string_1, string_2 = number_of_tuples
        ''.join(string_1)
        string_1_separated = " ".join(string_1)
        print(f"{required_formatting_dashes}\nGuess {Guess_number}:  {string_1_separated}\n         {string_2}")
        Guess_number += 1 
    print(f"{required_formatting_dashes}\n")

def print_keyboard(history: tuple[tuple[str,str],...]) -> None:
    """
    prints the keyboard in two columns
    prints the blocks indicating CORRECT/INCORRECT/MISPLACED/UNSEEN next to letter
    """
    required_formatting_dashes_2 = 12*"-"
    print(f"\nKeyboard information\n{required_formatting_dashes_2}")
    Saved_info = dict()
    length_of_history = len(history)
    for letters in ascii_lowercase:
        #determines the unseen letters
        if letters not in history:
            Saved_info[letters] = UNSEEN
    for positions in range(length_of_history):
        letter, block = history[positions]
        for x in range(6):
            #stores the correct, incorrect and misplaced info into letters
            if block[x] == CORRECT:
                Saved_info[letter[x]] = CORRECT 
            elif block[x] == INCORRECT:
                Saved_info[letter[x]] = INCORRECT 
            else:
                Saved_info[letter[x]] = MISPLACED
    for alphabets in ascii_lowercase:
        #prints the alphabet in correct format
        if ord(alphabets)%2 != 0:
            print(f"{alphabets}: {Saved_info[alphabets]}\t", end='')
        else:
            print(f"{alphabets}: {Saved_info[alphabets]}")
    print("")

def print_stats(stats: tuple[int, ...]) -> None:
    """
    prints the stats of the gameplay
    ie. games lost, games won in which round
    """
    a, b, c, d, e, f, g = stats 
    print(f"\nGames won in:\n1 moves: {a}\n2 moves: {b}\n3 moves: {c}\n4 moves: {d}\n5 moves: {e}\n6 moves: {f}\nGames lost: {g}")

def main():
    guess_number = 1
    words = load_words(VOCAB_FILE)
    answer = choose_word(load_words(ANSWERS_FILE))
    history = ()
    equal = True
    stats = [0, 0, 0, 0, 0, 0, 0]
    while equal:
        user_guess = prompt_user(guess_number, words)
        if user_guess == 'h':
            print("Ah, you need help? Unfortunate.")
        elif user_guess == 'q':
            return False
        elif user_guess == 'k':
            print_keyboard(history)
        else:
            if has_won(user_guess, answer) == False:
                history = update_history(history, user_guess, answer)
                print_history(history)
            if has_won(user_guess, answer) == True:
                stats[guess_number] += 1
                history = update_history(history, user_guess, answer)
                print_history(history)
                print(f"Correct! You won in {str(guess_number + 1)} guesses!")
            if has_lost(guess_number) == True:
                print(f"You lose! The answer was: {answer}")
                stats[6] += 1
            guess_number += 1 
    print_stats(stats)
    Again = input("Would you like to play again (y/n)? ")
    if Again == "y":
        equal = True 
    else:
        equal = False 



if __name__ == "__main__":
    main()

